export const THEMESE = [
  {
    label: "Light Theme 1",
    value: "theme-light-1",
  },
  {
    label: "Light Theme 2",
    value: "theme-light-2",
  },
  {
    label: "Light Theme 3",
    value: "theme-light-3",
  },
  {
    label: "Dark Theme 1",
    value: "theme-dark-1",
  },
  {
    label: "Dark Theme  2",
    value: "theme-dark-2",
  },
  {
    label: "Dark Theme  3",
    value: "theme-dark-3",
  },
];
