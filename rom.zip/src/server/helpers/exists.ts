export function $exists<T>(ts: T[]): boolean {
  return ts.length > 0;
}
