export const ROLES = [
  {
    id: 0,
    value: {
      key: "USER",
      name: "User",
    },
  },
  {
    id: 1,
    value: {
      key: "ADMIN",
      name: "Admin",
    },
  },
  {
    id: 2,
    value: {
      key: "ROOM",
      name: "Room",
    },
  },
];
